
# Week 2 Assignment: HOG Features and Image Classification

## Project Overview

This project implements Histogram of Oriented Gradients (HOG) feature extraction and compares two classical machine-learning classifiers for image classification: Linear Support Vector Machine (SVM) and k-Nearest Neighbors (k-NN).

The three image classes are cats, dogs, and birds.

## Dataset

- Total images: 75
- Cats: 25 images
- Dogs: 25 images
- Birds: 25 images
- Dataset source: CIFAR-10
- Dataset reference: https://www.cs.toronto.edu/~kriz/cifar.html

The dataset is organized as:

```text
dataset/
├── cats/
├── dogs/
└── birds/
```

## HOG Feature Settings

| Setting | Orientations | Pixels per cell | Cells per block | Feature length |
|---|---:|---|---|---:|
| A | 9 | (8, 8) | (2, 2) | 324 |
| B | 9 | (16, 16) | (2, 2) | 36 |

## Classifier Results

The experiment used an 80/20 stratified train/test split, with random state 42.

| Classifier | Test accuracy |
|---|---:|
| Linear SVM | 66.67% |
| k-NN (k=5) | 26.67% |

Linear SVM performed better on this test split. Because the dataset and test set are small, these results should be interpreted cautiously.

## Project Files

- `extract_features.py` — extracts HOG features for both settings.
- `compare_classifiers.py` — trains and evaluates Linear SVM and k-NN.
- `analysis.md` — discusses feature lengths, classifier results, confusion patterns, and practical use cases.
- `classifier_results.txt` — saved classifier accuracy results.
- `features/` — saved HOG feature arrays and labels.
- `visualizations/` — HOG comparison images for birds, cats, and dogs.
- `dataset/` — image folders for the three classes.

## How to Run

Run the following commands in an environment with Python, NumPy, scikit-image, and scikit-learn installed:

```bash
python extract_features.py
python compare_classifiers.py
```

The dataset images must be available under `dataset/` before running the scripts.

## Notes

The extracted feature arrays were generated from the included images. If the dataset is not included in the repository, obtain CIFAR-10 from the official source and regenerate the JPG images before running the scripts.
