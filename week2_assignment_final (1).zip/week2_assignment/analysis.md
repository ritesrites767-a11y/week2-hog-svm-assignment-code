
# Week 2 Assignment: HOG Features and Image Classification

## Dataset and Experimental Setup

This experiment classifies three image categories: cats, dogs, and birds. The dataset contains 25 images per class, for a total of 75 images. The images were organized into separate class folders.

The HOG features were extracted using Setting A:
- Orientations: 9
- Pixels per cell: (8, 8)
- Cells per block: (2, 2)

The feature matrix contains 75 samples and 324 features per image. The data was divided into 80% training data (60 images) and 20% testing data (15 images), using stratified sampling and random state 42.

## 1. Compare the Feature Vector Lengths

Setting A uses pixels_per_cell=(8, 8), while Setting B uses pixels_per_cell=(16, 16). Both settings use 9 orientations and cells_per_block=(2, 2).

Setting A produced 324 features per image, while Setting B produced 36 features per image.

Setting A has a longer feature vector because smaller cells preserve more spatial detail. This can help represent the shapes and edges of objects, but it also increases the amount of data used for training. Setting B produces a shorter representation, which is more compact but may lose some detail.

## 2. Compare Classifier Accuracy

The measured test accuracies were:

| Classifier | Test accuracy |
|---|---:|
| Linear SVM | 66.67% |
| k-NN (k=5) | 26.67% |

Linear SVM performed better than k-NN in this experiment, achieving 66.67% accuracy compared with 26.67% for k-NN.

The dataset is small, containing only 75 images, and the test set contains 15 images. Therefore, each incorrect prediction changes the accuracy by approximately 6.67 percentage points. These results should be treated as an initial comparison rather than proof that one classifier is always better.

## 3. Which Classes Were Most Confused, and How Could This Be Improved?

For Linear SVM, the confusion matrix uses the class order birds, cats, dogs:

| Actual class | Predicted birds | Predicted cats | Predicted dogs |
|---|---:|---:|---:|
| Birds | 3 | 0 | 2 |
| Cats | 1 | 2 | 2 |
| Dogs | 0 | 0 | 5 |

The most notable confusion was between cats and dogs: 2 actual cats were predicted as dogs, and 0 actual dogs were predicted as cats. Birds were also confused with dogs twice.

A possible improvement is to collect more varied and higher-resolution images, ensure consistent image preprocessing, and test other HOG settings. Cross-validation could provide a more reliable estimate of performance. A larger dataset would help determine whether the observed confusions persist.

## 4. When Might HOG and a Classical Classifier Be Preferred Over a CNN?

HOG with a classical classifier can be useful when a project has limited training data, modest computing resources, and a need for a relatively simple model. For example, a small industrial inspection system could classify a few types of clearly defined parts based on their outlines and edge patterns.

A CNN may be preferable when large datasets and sufficient computing resources are available, particularly when images contain complex backgrounds, significant changes in lighting, or varied object appearances.

The appropriate approach depends on the data, accuracy requirements, computational budget, and deployment environment.

## Conclusion

In this experiment, HOG Setting A produced 324 features per image. Linear SVM achieved 66.67% test accuracy, while k-NN achieved 26.67%. Linear SVM was the stronger of the two classifiers on this particular split. More data and additional evaluation would be needed before drawing broader conclusions.

## Dataset Source

The images were selected from the CIFAR-10 dataset, using its bird, cat, and dog categories. Dataset reference: https://www.cs.toronto.edu/~kriz/cifar.html

The images in this assignment were saved as JPG files for feature extraction.
