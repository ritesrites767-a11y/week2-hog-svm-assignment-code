
import os
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import make_pipeline
from sklearn.svm import LinearSVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

PROJECT_DIR = "/content/week2_assignment"
FEATURE_PATH = os.path.join(
    PROJECT_DIR, "features", "hog_features_setting_a.npz"
)

# Load HOG features and text labels
data = np.load(FEATURE_PATH)
X = data["X"]
y_text = data["y"]

# Convert class names into numeric labels
encoder = LabelEncoder()
y = encoder.fit_transform(y_text)
class_names = encoder.classes_

print("Classes:", list(class_names))
print("Feature shape:", X.shape)
print("Label counts:", {
    name: int(np.sum(y_text == name)) for name in class_names
})

# 80% training, 20% testing
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

models = {
    "Linear SVM": make_pipeline(
        StandardScaler(),
        LinearSVC(random_state=42, max_iter=10000)
    ),
    "k-NN (k=5)": make_pipeline(
        StandardScaler(),
        KNeighborsClassifier(n_neighbors=5)
    )
}

results = []

for name, model in models.items():
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    accuracy = accuracy_score(y_test, predictions)
    results.append((name, accuracy))

    print("\n" + "=" * 50)
    print(name)
    print(f"Accuracy: {accuracy:.4f} ({accuracy * 100:.2f}%)")

    print("\nClassification report:")
    print(classification_report(
        y_test,
        predictions,
        labels=np.arange(len(class_names)),
        target_names=class_names,
        zero_division=0
    ))

    print("Confusion matrix (rows = actual, columns = predicted):")
    print(confusion_matrix(
        y_test,
        predictions,
        labels=np.arange(len(class_names))
    ))

print("\nSUMMARY")
for name, accuracy in results:
    print(f"{name}: {accuracy:.4f} ({accuracy * 100:.2f}%)")

# Save results for the assignment report
results_path = os.path.join(PROJECT_DIR, "classifier_results.txt")
with open(results_path, "w") as f:
    f.write("HOG Setting A: Linear SVM vs k-NN (k=5)\n")
    f.write(f"Feature shape: {X.shape}\n")
    f.write(f"Classes: {', '.join(class_names)}\n\n")
    for name, accuracy in results:
        f.write(f"{name}: {accuracy:.4f} ({accuracy * 100:.2f}%)\n")

print("\nResults saved to:", results_path)
