
import os
import numpy as np
import matplotlib.pyplot as plt

from PIL import Image
from skimage.color import rgb2gray
from skimage.feature import hog

PROJECT_DIR = "/content/week2_assignment"
DATASET_DIR = os.path.join(PROJECT_DIR, "dataset")
FEATURE_DIR = os.path.join(PROJECT_DIR, "features")
VIS_DIR = os.path.join(PROJECT_DIR, "visualizations")

os.makedirs(FEATURE_DIR, exist_ok=True)
os.makedirs(VIS_DIR, exist_ok=True)

CLASSES = ["cats", "dogs", "birds"]

# Required HOG parameter settings
SETTINGS = {
    "A": {
        "orientations": 9,
        "pixels_per_cell": (8, 8),
        "cells_per_block": (2, 2),
    },
    "B": {
        "orientations": 9,
        "pixels_per_cell": (16, 16),
        "cells_per_block": (2, 2),
    },
}

def load_grayscale_image(image_path):
    """Load an image and convert it to grayscale."""
    image = Image.open(image_path).convert("RGB")
    image = np.array(image)
    return rgb2gray(image)

def extract_hog_features(image, parameters, visualize=False):
    """Extract HOG features using the supplied parameters."""
    return hog(
        image,
        orientations=parameters["orientations"],
        pixels_per_cell=parameters["pixels_per_cell"],
        cells_per_block=parameters["cells_per_block"],
        block_norm="L2-Hys",
        visualize=visualize,
        feature_vector=True,
    )

# Collect image paths and labels in a consistent order
image_paths = []
labels = []

for class_name in CLASSES:
    class_dir = os.path.join(DATASET_DIR, class_name)

    for filename in sorted(os.listdir(class_dir)):
        if filename.lower().endswith((".jpg", ".jpeg", ".png")):
            image_paths.append(os.path.join(class_dir, filename))
            labels.append(class_name)

labels = np.array(labels)

print("Total images:", len(image_paths))
print("Classes:", CLASSES)

# Extract and save features for both settings
for setting_name, parameters in SETTINGS.items():
    all_features = []

    for image_path in image_paths:
        gray_image = load_grayscale_image(image_path)
        features = extract_hog_features(gray_image, parameters)
        all_features.append(features)

    X = np.array(all_features)

    output_path = os.path.join(
        FEATURE_DIR, f"hog_features_setting_{setting_name.lower()}.npz"
    )

    np.savez_compressed(
        output_path,
        X=X,
        y=labels,
        image_paths=np.array(image_paths),
    )

    print(f"\nSetting {setting_name}")
    print("Parameters:", parameters)
    print("Feature matrix shape:", X.shape)
    print("Feature vector length:", X.shape[1])
    print("Saved:", output_path)

# Save one original-versus-HOG visualization per class, using Setting A
for class_name in CLASSES:
    class_dir = os.path.join(DATASET_DIR, class_name)
    filenames = sorted([
        f for f in os.listdir(class_dir)
        if f.lower().endswith((".jpg", ".jpeg", ".png"))
    ])

    image_path = os.path.join(class_dir, filenames[0])
    gray_image = load_grayscale_image(image_path)

    features, hog_image = hog(
        gray_image,
        orientations=9,
        pixels_per_cell=(8, 8),
        cells_per_block=(2, 2),
        block_norm="L2-Hys",
        visualize=True,
        feature_vector=True,
    )

    fig, axes = plt.subplots(1, 2, figsize=(8, 4))

    axes[0].imshow(gray_image, cmap="gray")
    axes[0].set_title(f"Original: {class_name}")

    axes[1].imshow(hog_image, cmap="gray")
    axes[1].set_title("HOG visualization (Setting A)")

    for ax in axes:
        ax.axis("off")

    plt.tight_layout()

    output_path = os.path.join(
        VIS_DIR, f"{class_name}_hog_comparison.png"
    )
    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.show()
    plt.close(fig)

    print("Visualization saved:", output_path)

print("\nSUCCESS: HOG extraction and visualizations completed.")
